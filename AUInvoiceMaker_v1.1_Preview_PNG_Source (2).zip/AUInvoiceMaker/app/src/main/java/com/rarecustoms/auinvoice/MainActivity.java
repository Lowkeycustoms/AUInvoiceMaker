package com.rarecustoms.auinvoice;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_LOGO = 1201;
    private static final int BG = Color.rgb(10, 13, 16);
    private static final int PANEL = Color.rgb(18, 24, 32);
    private static final int CYAN = Color.rgb(0, 229, 255);
    private static final int WHITE = Color.rgb(247, 251, 255);
    private static final int MUTED = Color.rgb(167, 181, 194);
    private static final int RED = Color.rgb(255, 92, 92);

    private SharedPreferences prefs;
    private LinearLayout itemsContainer;
    private ImageView logoPreview;
    private Uri logoUri;

    private EditText businessName, businessAbn, businessAddress, businessContact, paymentDetails;
    private EditText customerName, customerBusiness, customerAbn, customerEmail, customerAddress;
    private EditText invoiceNumber, issueDate, dueDate, reference, notes;
    private CheckBox gstRegistered, pricesIncludeGst;
    private TextView subtotalText, gstText, totalText, documentTypeText, complianceText;

    private final List<ItemViews> itemRows = new ArrayList<>();
    private final NumberFormat money = NumberFormat.getCurrencyInstance(new Locale("en", "AU"));
    private String lastExportedInvoiceNumber = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("au_invoice_prefs", MODE_PRIVATE);
        setContentView(buildUi());
        loadProfile();
        if (itemRows.isEmpty()) addItemRow("", "1", "", true);
        recalculate();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(40));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("AU INVOICE MAKER", 24, WHITE, true);
        root.addView(title);
        TextView subtitle = text("Australian invoices • GST • Preview • PDF • PNG • Offline", 13, MUTED, false);
        subtitle.setPadding(0, dp(3), 0, dp(16));
        root.addView(subtitle);

        documentTypeText = text("INVOICE", 14, CYAN, true);
        documentTypeText.setGravity(Gravity.CENTER);
        documentTypeText.setPadding(dp(12), dp(9), dp(12), dp(9));
        documentTypeText.setBackground(strokeBg(PANEL, CYAN, 1, 10));
        root.addView(documentTypeText, matchWrap());

        root.addView(section("BUSINESS PROFILE"));
        LinearLayout businessCard = card();
        root.addView(businessCard);

        LinearLayout logoLine = new LinearLayout(this);
        logoLine.setOrientation(LinearLayout.HORIZONTAL);
        logoLine.setGravity(Gravity.CENTER_VERTICAL);
        logoPreview = new ImageView(this);
        logoPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logoPreview.setBackground(strokeBg(BG, CYAN, 1, 8));
        logoLine.addView(logoPreview, new LinearLayout.LayoutParams(dp(76), dp(76)));
        Button logoBtn = button("ADD / CHANGE LOGO", false);
        LinearLayout.LayoutParams logoBtnParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        logoBtnParams.setMargins(dp(12), 0, 0, 0);
        logoLine.addView(logoBtn, logoBtnParams);
        logoBtn.setOnClickListener(v -> pickLogo());
        businessCard.addView(logoLine);

        businessName = field("Business / legal name", InputType.TYPE_CLASS_TEXT);
        businessAbn = field("ABN (11 digits)", InputType.TYPE_CLASS_NUMBER);
        businessAddress = field("Business address", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        businessContact = field("Email / phone", InputType.TYPE_CLASS_TEXT);
        paymentDetails = field("Payment details (account name, BSB, account number, PayID, etc.)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        businessCard.addView(businessName); businessCard.addView(businessAbn); businessCard.addView(businessAddress); businessCard.addView(businessContact); businessCard.addView(paymentDetails);

        gstRegistered = checkbox("Registered for GST", false);
        pricesIncludeGst = checkbox("Line prices include GST", true);
        businessCard.addView(gstRegistered);
        businessCard.addView(pricesIncludeGst);
        pricesIncludeGst.setEnabled(false);
        gstRegistered.setOnCheckedChangeListener((b, checked) -> {
            pricesIncludeGst.setEnabled(checked);
            updateDocumentType(); recalculate();
        });
        pricesIncludeGst.setOnCheckedChangeListener((b, checked) -> recalculate());

        Button saveProfile = button("SAVE BUSINESS PROFILE", true);
        businessCard.addView(saveProfile, buttonParams());
        saveProfile.setOnClickListener(v -> { saveProfile(); toast("Business profile saved on this phone"); });

        root.addView(section("CUSTOMER"));
        LinearLayout customerCard = card();
        root.addView(customerCard);
        customerName = field("Customer name / contact", InputType.TYPE_CLASS_TEXT);
        customerBusiness = field("Customer business name", InputType.TYPE_CLASS_TEXT);
        customerAbn = field("Customer ABN (optional)", InputType.TYPE_CLASS_NUMBER);
        customerEmail = field("Customer email", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        customerAddress = field("Customer address", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        customerCard.addView(customerName); customerCard.addView(customerBusiness); customerCard.addView(customerAbn); customerCard.addView(customerEmail); customerCard.addView(customerAddress);

        root.addView(section("INVOICE DETAILS"));
        LinearLayout detailsCard = card();
        root.addView(detailsCard);
        invoiceNumber = field("Invoice number", InputType.TYPE_CLASS_TEXT);
        issueDate = field("Issue date", InputType.TYPE_CLASS_DATETIME);
        dueDate = field("Due date", InputType.TYPE_CLASS_DATETIME);
        issueDate.setFocusable(false); dueDate.setFocusable(false);
        issueDate.setOnClickListener(v -> pickDate(issueDate));
        dueDate.setOnClickListener(v -> pickDate(dueDate));
        reference = field("Reference / PO number (optional)", InputType.TYPE_CLASS_TEXT);
        detailsCard.addView(invoiceNumber); detailsCard.addView(issueDate); detailsCard.addView(dueDate); detailsCard.addView(reference);

        root.addView(section("ITEMS"));
        itemsContainer = new LinearLayout(this);
        itemsContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(itemsContainer);
        Button addItem = button("+ ADD LINE ITEM", false);
        root.addView(addItem, buttonParams());
        addItem.setOnClickListener(v -> addItemRow("", "1", "", true));

        root.addView(section("NOTES"));
        notes = field("Notes / payment terms / thank-you message", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        notes.setMinLines(3);
        root.addView(notes);

        LinearLayout totals = card();
        LinearLayout.LayoutParams totalsParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        totalsParams.setMargins(0, dp(18), 0, dp(12));
        root.addView(totals, totalsParams);
        subtotalText = totalLine("Subtotal", "$0.00", false, totals);
        gstText = totalLine("GST", "$0.00", false, totals);
        totalText = totalLine("TOTAL AUD", "$0.00", true, totals);

        complianceText = text("", 12, MUTED, false);
        complianceText.setPadding(dp(4), dp(4), dp(4), dp(14));
        root.addView(complianceText);

        Button previewInvoice = button("PREVIEW COMPLETE INVOICE", true);
        root.addView(previewInvoice, buttonParams());
        previewInvoice.setOnClickListener(v -> previewInvoice());

        Button savePdf = button("SAVE PDF", false);
        root.addView(savePdf, buttonParams());
        savePdf.setOnClickListener(v -> generate(false));

        Button savePng = button("SAVE PNG", false);
        root.addView(savePng, buttonParams());
        savePng.setOnClickListener(v -> savePng());

        Button sharePdf = button("SHARE PDF", false);
        root.addView(sharePdf, buttonParams());
        sharePdf.setOnClickListener(v -> generate(true));

        Button newInvoice = button("NEW INVOICE", false);
        root.addView(newInvoice, buttonParams());
        newInvoice.setOnClickListener(v -> newInvoice());

        TextView footer = text("Data stays on your phone. PDFs save to Documents/AU Invoice Maker and PNGs save to Pictures/AU Invoice Maker.", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(12), 0, 0);
        root.addView(footer);

        return scroll;
    }

    private void addItemRow(String desc, String qty, String price, boolean taxable) {
        LinearLayout row = card();
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.setMargins(0, 0, 0, dp(10));
        itemsContainer.addView(row, rp);

        EditText d = field("Description of goods / services", InputType.TYPE_CLASS_TEXT);
        row.addView(d); d.setText(desc);

        LinearLayout numbers = new LinearLayout(this);
        numbers.setOrientation(LinearLayout.HORIZONTAL);
        EditText q = field("Qty", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText p = field("Unit price", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout.LayoutParams half1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.35f);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.65f);
        half1.setMargins(0, 0, dp(5), 0); half2.setMargins(dp(5), 0, 0, 0);
        numbers.addView(q, half1); numbers.addView(p, half2);
        q.setText(qty); p.setText(price);
        row.addView(numbers);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        CheckBox t = checkbox("GST taxable", taxable);
        actions.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button del = button("REMOVE", false);
        del.setTextColor(RED);
        actions.addView(del, new LinearLayout.LayoutParams(dp(105), dp(44)));
        row.addView(actions);

        ItemViews iv = new ItemViews(row, d, q, p, t);
        itemRows.add(iv);
        TextWatcher watcher = new SimpleWatcher(this::recalculate);
        q.addTextChangedListener(watcher); p.addTextChangedListener(watcher); d.addTextChangedListener(watcher);
        t.setOnCheckedChangeListener((b, c) -> recalculate());
        del.setOnClickListener(v -> {
            if (itemRows.size() <= 1) {
                d.setText(""); q.setText("1"); p.setText(""); t.setChecked(true);
            } else {
                itemRows.remove(iv); itemsContainer.removeView(row); recalculate();
            }
        });
        recalculate();
    }

    private void recalculate() {
        double subtotal = 0, gst = 0, total = 0;
        boolean reg = gstRegistered != null && gstRegistered.isChecked();
        boolean inclusive = pricesIncludeGst != null && pricesIncludeGst.isChecked();
        for (ItemViews iv : itemRows) {
            double line = number(iv.qty.getText().toString()) * number(iv.price.getText().toString());
            boolean taxable = reg && iv.taxable.isChecked();
            if (taxable && inclusive) {
                double lineGst = line / 11.0;
                subtotal += line - lineGst; gst += lineGst; total += line;
            } else if (taxable) {
                subtotal += line; double lineGst = line * 0.10; gst += lineGst; total += line + lineGst;
            } else {
                subtotal += line; total += line;
            }
        }
        if (subtotalText != null) subtotalText.setText(money.format(subtotal));
        if (gstText != null) gstText.setText(money.format(gst));
        if (totalText != null) totalText.setText(money.format(total));
        if (complianceText != null) {
            String msg = reg
                    ? "Tax Invoice mode: GST is calculated at 10%. " + (inclusive ? "Entered prices are GST-inclusive." : "GST is added to taxable line prices.")
                    : "Invoice mode: GST is not charged and the PDF will not be labelled Tax Invoice.";
            if (reg && total >= 1000) msg += " Buyer identity details are required for a $1,000+ tax invoice.";
            complianceText.setText(msg);
        }
    }

    private Totals getTotals() {
        double subtotal = 0, gst = 0, total = 0;
        boolean reg = gstRegistered.isChecked();
        boolean inclusive = pricesIncludeGst.isChecked();
        for (ItemViews iv : itemRows) {
            double line = number(iv.qty.getText().toString()) * number(iv.price.getText().toString());
            boolean taxable = reg && iv.taxable.isChecked();
            if (taxable && inclusive) {
                double g = line / 11.0; subtotal += line - g; gst += g; total += line;
            } else if (taxable) {
                subtotal += line; double g = line * .10; gst += g; total += line + g;
            } else { subtotal += line; total += line; }
        }
        return new Totals(subtotal, gst, total);
    }

    private void generate(boolean share) {
        saveProfile();
        Totals totals = getTotals();
        String error = validateInvoice(totals);
        if (error != null) { toast(error); return; }

        String fileName = cleanFileName(invoiceNumber.getText().toString().trim()) + ".pdf";
        Uri uri = null;
        PdfDocument pdf = null;
        try {
            uri = createDocumentUri(fileName);
            if (uri == null) throw new Exception("Could not create document");
            pdf = buildPdf(totals);
            OutputStream out = getContentResolver().openOutputStream(uri);
            if (out == null) throw new Exception("Could not open output file");
            pdf.writeTo(out);
            out.flush(); out.close(); pdf.close(); pdf = null;

            markInvoiceExported();
            if (share) {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_SUBJECT, (gstRegistered.isChecked() ? "Tax Invoice " : "Invoice ") + invoiceNumber.getText().toString());
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(send, "Share invoice PDF"));
            } else {
                toast("PDF saved to Documents/AU Invoice Maker");
            }
        } catch (Exception e) {
            if (pdf != null) pdf.close();
            if (uri != null) try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
            toast("Could not create PDF: " + e.getMessage());
        }
    }

    private void previewInvoice() {
        saveProfile();
        Totals totals = getTotals();
        String error = validateInvoice(totals);
        if (error != null) { toast(error); return; }

        File temp = null;
        final List<Bitmap> pages = new ArrayList<>();
        try {
            temp = writeTempPdf(totals);
            pages.addAll(renderPdfPages(temp, 900));
            if (pages.isEmpty()) throw new Exception("No invoice pages could be rendered");

            ScrollView scroll = new ScrollView(this);
            scroll.setBackgroundColor(Color.rgb(235, 238, 242));
            LinearLayout previewRoot = new LinearLayout(this);
            previewRoot.setOrientation(LinearLayout.VERTICAL);
            previewRoot.setPadding(dp(10), dp(10), dp(10), dp(16));
            scroll.addView(previewRoot, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            for (int i = 0; i < pages.size(); i++) {
                TextView pageLabel = text("PAGE " + (i + 1) + " OF " + pages.size(), 11, Color.DKGRAY, true);
                pageLabel.setGravity(Gravity.CENTER);
                pageLabel.setPadding(0, dp(6), 0, dp(6));
                previewRoot.addView(pageLabel);

                ImageView pageView = new ImageView(this);
                pageView.setAdjustViewBounds(true);
                pageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                pageView.setBackgroundColor(Color.WHITE);
                pageView.setImageBitmap(pages.get(i));
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                ip.setMargins(0, 0, 0, dp(14));
                previewRoot.addView(pageView, ip);
            }

            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("Complete Invoice Preview")
                    .setView(scroll)
                    .setPositiveButton("CLOSE", null)
                    .setNeutralButton("SAVE PNG", (d, which) -> savePng())
                    .create();
            dialog.setOnDismissListener(d -> {
                for (Bitmap b : pages) if (b != null && !b.isRecycled()) b.recycle();
            });
            dialog.show();
        } catch (Exception e) {
            for (Bitmap b : pages) if (b != null && !b.isRecycled()) b.recycle();
            toast("Could not preview invoice: " + e.getMessage());
        } finally {
            if (temp != null) try { temp.delete(); } catch (Exception ignored) {}
        }
    }

    private void savePng() {
        saveProfile();
        Totals totals = getTotals();
        String error = validateInvoice(totals);
        if (error != null) { toast(error); return; }

        File temp = null;
        List<Bitmap> pages = new ArrayList<>();
        Bitmap combined = null;
        Uri uri = null;
        try {
            temp = writeTempPdf(totals);
            int pageCount = getPdfPageCount(temp);
            int targetWidth = pageCount <= 2 ? 1190 : (pageCount <= 4 ? 900 : 700);
            pages = renderPdfPages(temp, targetWidth);
            if (pages.isEmpty()) throw new Exception("No invoice pages could be rendered");
            combined = combinePages(pages);

            String fileName = cleanFileName(invoiceNumber.getText().toString().trim()) + ".png";
            uri = createPngUri(fileName);
            if (uri == null) throw new Exception("Could not create PNG file");
            OutputStream out = getContentResolver().openOutputStream(uri);
            if (out == null) throw new Exception("Could not open PNG output file");
            if (!combined.compress(Bitmap.CompressFormat.PNG, 100, out)) throw new Exception("PNG encoding failed");
            out.flush(); out.close();
            markInvoiceExported();
            toast("PNG saved to Pictures/AU Invoice Maker");
        } catch (Exception e) {
            if (uri != null) try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
            toast("Could not create PNG: " + e.getMessage());
        } finally {
            if (combined != null && !combined.isRecycled()) combined.recycle();
            for (Bitmap b : pages) if (b != null && !b.isRecycled()) b.recycle();
            if (temp != null) try { temp.delete(); } catch (Exception ignored) {}
        }
    }

    private File writeTempPdf(Totals totals) throws Exception {
        File temp = new File(getCacheDir(), "invoice_preview_" + System.currentTimeMillis() + ".pdf");
        PdfDocument pdf = null;
        try {
            pdf = buildPdf(totals);
            try (FileOutputStream out = new FileOutputStream(temp)) {
                pdf.writeTo(out);
                out.flush();
            }
            pdf.close();
            return temp;
        } catch (Exception e) {
            if (pdf != null) try { pdf.close(); } catch (Exception ignored) {}
            try { temp.delete(); } catch (Exception ignored) {}
            throw e;
        }
    }

    private int getPdfPageCount(File pdfFile) throws Exception {
        try (ParcelFileDescriptor pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer renderer = new PdfRenderer(pfd)) {
            return renderer.getPageCount();
        }
    }

    private List<Bitmap> renderPdfPages(File pdfFile, int targetWidth) throws Exception {
        List<Bitmap> pages = new ArrayList<>();
        try (ParcelFileDescriptor pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer renderer = new PdfRenderer(pfd)) {
            for (int i = 0; i < renderer.getPageCount(); i++) {
                PdfRenderer.Page page = renderer.openPage(i);
                try {
                    float scale = targetWidth / (float) page.getWidth();
                    int width = Math.max(1, Math.round(page.getWidth() * scale));
                    int height = Math.max(1, Math.round(page.getHeight() * scale));
                    Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    bitmap.eraseColor(Color.WHITE);
                    Matrix matrix = new Matrix();
                    matrix.postScale(scale, scale);
                    page.render(bitmap, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    pages.add(bitmap);
                } finally {
                    page.close();
                }
            }
        }
        return pages;
    }

    private Bitmap combinePages(List<Bitmap> pages) {
        int gap = Math.max(12, dp(10));
        int width = 1;
        long totalHeightLong = 0;
        for (Bitmap b : pages) {
            width = Math.max(width, b.getWidth());
            totalHeightLong += b.getHeight();
        }
        totalHeightLong += (long) gap * Math.max(0, pages.size() - 1);
        if (totalHeightLong > 20000) throw new IllegalArgumentException("Invoice is too long for one PNG. Save the PDF instead.");
        int height = (int) totalHeightLong;
        Bitmap out = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        canvas.drawColor(Color.WHITE);
        float y = 0;
        for (Bitmap b : pages) {
            float x = (width - b.getWidth()) / 2f;
            canvas.drawBitmap(b, x, y, null);
            y += b.getHeight() + gap;
        }
        return out;
    }

    private Uri createPngUri(String fileName) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AU Invoice Maker");
        return getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
    }

    private void markInvoiceExported() {
        String current = invoiceNumber.getText().toString().trim();
        if (current.isEmpty() || current.equals(lastExportedInvoiceNumber)) return;
        incrementInvoiceNumber();
        lastExportedInvoiceNumber = current;
    }

    private String validateInvoice(Totals totals) {
        if (businessName.getText().toString().trim().isEmpty()) return "Add your business name first";
        if (invoiceNumber.getText().toString().trim().isEmpty()) return "Add an invoice number";
        if (issueDate.getText().toString().trim().isEmpty()) return "Add the invoice issue date";
        boolean hasItem = false;
        for (ItemViews iv : itemRows) if (!iv.desc.getText().toString().trim().isEmpty()) { hasItem = true; break; }
        if (!hasItem) return "Add at least one item description";
        if (gstRegistered.isChecked()) {
            String abn = digits(businessAbn.getText().toString());
            if (!isValidAbn(abn)) return "Enter a valid 11-digit Australian ABN for Tax Invoice mode";
            if (totals.total >= 1000) {
                String buyer = (customerBusiness.getText().toString() + customerName.getText().toString()).trim();
                if (buyer.isEmpty()) return "For a $1,000+ tax invoice, add the buyer's identity";
                if (customerAddress.getText().toString().trim().isEmpty() && digits(customerAbn.getText().toString()).isEmpty())
                    return "For a $1,000+ tax invoice, add the buyer's address or ABN";
            }
        }
        return null;
    }

    private PdfDocument buildPdf(Totals totals) throws Exception {
        PdfDocument doc = new PdfDocument();
        PdfState ps = startPdfPage(doc, 1);
        float y = 46;

        Bitmap logo = loadLogoBitmap();
        if (logo != null) {
            float maxW = 120, maxH = 62;
            float scale = Math.min(maxW / logo.getWidth(), maxH / logo.getHeight());
            float w = logo.getWidth() * scale, h = logo.getHeight() * scale;
            ps.canvas.drawBitmap(logo, null, new RectF(40, y, 40 + w, y + h), ps.paint);
        }

        ps.paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        ps.paint.setTextSize(24); ps.paint.setColor(Color.BLACK);
        String docType = gstRegistered.isChecked() ? "TAX INVOICE" : "INVOICE";
        ps.canvas.drawText(docType, 555 - ps.paint.measureText(docType), y + 26, ps.paint);
        ps.paint.setTextSize(9); ps.paint.setColor(Color.DKGRAY);
        drawRight(ps.canvas, ps.paint, "Invoice # " + invoiceNumber.getText(), 555, y + 45);
        drawRight(ps.canvas, ps.paint, "Issue: " + issueDate.getText(), 555, y + 59);
        if (!dueDate.getText().toString().trim().isEmpty()) drawRight(ps.canvas, ps.paint, "Due: " + dueDate.getText(), 555, y + 73);
        y = 132;

        ps.paint.setColor(CYAN_DARK()); ps.canvas.drawRect(40, y, 555, y + 3, ps.paint); y += 18;
        ps.paint.setColor(Color.BLACK); ps.paint.setTextSize(10); ps.paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        ps.canvas.drawText("FROM", 40, y, ps.paint); ps.canvas.drawText("BILL TO", 315, y, ps.paint); y += 17;
        ps.paint.setTypeface(Typeface.DEFAULT); ps.paint.setTextSize(9);
        float leftY = y, rightY = y;
        leftY = drawWrap(ps, businessName.getText().toString(), 40, leftY, 230, 11);
        if (!businessAbn.getText().toString().trim().isEmpty()) leftY = drawWrap(ps, "ABN " + businessAbn.getText(), 40, leftY, 230, 11);
        leftY = drawWrap(ps, businessAddress.getText().toString(), 40, leftY, 230, 11);
        leftY = drawWrap(ps, businessContact.getText().toString(), 40, leftY, 230, 11);

        String buyerName = customerBusiness.getText().toString().trim();
        if (buyerName.isEmpty()) buyerName = customerName.getText().toString().trim();
        else if (!customerName.getText().toString().trim().isEmpty()) buyerName += "\nAttn: " + customerName.getText().toString().trim();
        rightY = drawWrap(ps, buyerName, 315, rightY, 240, 11);
        if (!customerAbn.getText().toString().trim().isEmpty()) rightY = drawWrap(ps, "ABN " + customerAbn.getText(), 315, rightY, 240, 11);
        rightY = drawWrap(ps, customerAddress.getText().toString(), 315, rightY, 240, 11);
        rightY = drawWrap(ps, customerEmail.getText().toString(), 315, rightY, 240, 11);
        y = Math.max(leftY, rightY) + 12;

        if (!reference.getText().toString().trim().isEmpty()) {
            ps.paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            ps.canvas.drawText("REFERENCE / PO", 40, y, ps.paint); ps.paint.setTypeface(Typeface.DEFAULT);
            ps.canvas.drawText(reference.getText().toString(), 130, y, ps.paint); y += 20;
        }

        y = drawTableHeader(ps, y);
        int itemIndex = 0;
        for (ItemViews iv : itemRows) {
            String desc = iv.desc.getText().toString().trim();
            if (desc.isEmpty()) continue;
            if (y > 690) {
                doc.finishPage(ps.page);
                ps = startPdfPage(doc, ++itemIndex + 1);
                y = 54;
                y = drawTableHeader(ps, y);
            }
            double qty = number(iv.qty.getText().toString());
            double unit = number(iv.price.getText().toString());
            double line = qty * unit;
            ps.paint.setTextSize(8.7f); ps.paint.setColor(Color.BLACK); ps.paint.setTypeface(Typeface.DEFAULT);
            List<String> lines = wrap(desc, ps.paint, 250);
            float rowH = Math.max(25, 8 + lines.size() * 11);
            float ty = y + 15;
            for (String l : lines) { ps.canvas.drawText(l, 46, ty, ps.paint); ty += 11; }
            drawRight(ps.canvas, ps.paint, trimQty(qty), 355, y + 16);
            drawRight(ps.canvas, ps.paint, money.format(unit), 448, y + 16);
            String gstLabel = gstRegistered.isChecked() ? (iv.taxable.isChecked() ? "10%" : "GST-free") : "—";
            drawRight(ps.canvas, ps.paint, gstLabel, 505, y + 16);
            drawRight(ps.canvas, ps.paint, money.format(line), 550, y + 16);
            ps.paint.setColor(Color.rgb(225, 230, 235)); ps.canvas.drawRect(40, y + rowH - 1, 555, y + rowH, ps.paint);
            y += rowH;
            itemIndex++;
        }

        y += 18;
        if (y > 700) { doc.finishPage(ps.page); ps = startPdfPage(doc, ++itemIndex + 1); y = 54; }
        ps.paint.setTextSize(9); ps.paint.setColor(Color.BLACK);
        float labelX = 395, valueX = 550;
        ps.canvas.drawText("Subtotal", labelX, y, ps.paint); drawRight(ps.canvas, ps.paint, money.format(totals.subtotal), valueX, y); y += 17;
        if (gstRegistered.isChecked()) {
            ps.canvas.drawText("GST", labelX, y, ps.paint); drawRight(ps.canvas, ps.paint, money.format(totals.gst), valueX, y); y += 17;
        }
        ps.paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD)); ps.paint.setTextSize(13); ps.paint.setColor(CYAN_DARK());
        ps.canvas.drawText("TOTAL AUD", labelX, y + 2, ps.paint); drawRight(ps.canvas, ps.paint, money.format(totals.total), valueX, y + 2); y += 32;
        ps.paint.setTypeface(Typeface.DEFAULT); ps.paint.setTextSize(8.5f); ps.paint.setColor(Color.DKGRAY);
        if (gstRegistered.isChecked()) {
            String gstStatement = pricesIncludeGst.isChecked() ? "Total price includes GST where applicable." : "GST of 10% has been added to taxable supplies.";
            ps.canvas.drawText(gstStatement, 40, y, ps.paint); y += 15;
        }

        if (!paymentDetails.getText().toString().trim().isEmpty()) {
            ps.paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD)); ps.paint.setTextSize(9); ps.paint.setColor(Color.BLACK);
            ps.canvas.drawText("PAYMENT DETAILS", 40, y, ps.paint); y += 14; ps.paint.setTypeface(Typeface.DEFAULT); ps.paint.setColor(Color.DKGRAY);
            y = drawWrap(ps, paymentDetails.getText().toString(), 40, y, 300, 11) + 4;
        }
        if (!notes.getText().toString().trim().isEmpty()) {
            ps.paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD)); ps.paint.setTextSize(9); ps.paint.setColor(Color.BLACK);
            ps.canvas.drawText("NOTES", 40, y, ps.paint); y += 14; ps.paint.setTypeface(Typeface.DEFAULT); ps.paint.setColor(Color.DKGRAY);
            drawWrap(ps, notes.getText().toString(), 40, y, 500, 11);
        }

        footer(ps);
        doc.finishPage(ps.page);
        return doc;
    }

    private PdfState startPdfPage(PdfDocument doc, int pageNum) {
        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, pageNum).create();
        PdfDocument.Page page = doc.startPage(info);
        Canvas c = page.getCanvas(); c.drawColor(Color.WHITE);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.BLACK);
        return new PdfState(page, c, p);
    }

    private float drawTableHeader(PdfState ps, float y) {
        ps.paint.setColor(Color.rgb(18, 24, 32)); ps.canvas.drawRect(40, y, 555, y + 25, ps.paint);
        ps.paint.setColor(Color.WHITE); ps.paint.setTextSize(8.5f); ps.paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        ps.canvas.drawText("DESCRIPTION", 46, y + 16, ps.paint);
        drawRight(ps.canvas, ps.paint, "QTY", 355, y + 16); drawRight(ps.canvas, ps.paint, "UNIT", 448, y + 16); drawRight(ps.canvas, ps.paint, "GST", 505, y + 16); drawRight(ps.canvas, ps.paint, "AMOUNT", 550, y + 16);
        return y + 25;
    }

    private void footer(PdfState ps) {
        ps.paint.setColor(Color.rgb(225, 230, 235)); ps.canvas.drawRect(40, 812, 555, 813, ps.paint);
        ps.paint.setTextSize(7.5f); ps.paint.setColor(Color.GRAY); ps.paint.setTypeface(Typeface.DEFAULT);
        ps.canvas.drawText("Generated with AU Invoice Maker • Amounts shown in Australian dollars (AUD)", 40, 827, ps.paint);
    }

    private float drawWrap(PdfState ps, String value, float x, float y, float maxWidth, float lineH) {
        if (value == null || value.trim().isEmpty()) return y;
        for (String para : value.split("\\n")) {
            for (String line : wrap(para, ps.paint, maxWidth)) { ps.canvas.drawText(line, x, y, ps.paint); y += lineH; }
        }
        return y;
    }

    private List<String> wrap(String text, Paint p, float max) {
        List<String> out = new ArrayList<>();
        if (text == null || text.trim().isEmpty()) { out.add(""); return out; }
        String[] words = text.trim().split("\\s+");
        StringBuilder line = new StringBuilder();
        for (String w : words) {
            String test = line.length() == 0 ? w : line + " " + w;
            if (p.measureText(test) <= max) line = new StringBuilder(test);
            else { if (line.length() > 0) out.add(line.toString()); line = new StringBuilder(w); }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    private Uri createDocumentUri(String fileName) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS + "/AU Invoice Maker");
        return getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
    }

    private void pickLogo() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_LOGO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_LOGO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            logoUri = data.getData();
            try { getContentResolver().takePersistableUriPermission(logoUri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            prefs.edit().putString("logoUri", logoUri.toString()).apply();
            displayLogo();
        }
    }

    private Bitmap loadLogoBitmap() {
        if (logoUri == null) return null;
        try (InputStream in = getContentResolver().openInputStream(logoUri)) { return BitmapFactory.decodeStream(in); }
        catch (Exception e) { return null; }
    }

    private void displayLogo() {
        Bitmap b = loadLogoBitmap();
        if (b != null) logoPreview.setImageBitmap(b); else logoPreview.setImageDrawable(null);
    }

    private void saveProfile() {
        prefs.edit()
                .putString("businessName", val(businessName)).putString("businessAbn", val(businessAbn))
                .putString("businessAddress", val(businessAddress)).putString("businessContact", val(businessContact))
                .putString("paymentDetails", val(paymentDetails)).putBoolean("gstRegistered", gstRegistered.isChecked())
                .putBoolean("pricesIncludeGst", pricesIncludeGst.isChecked()).apply();
    }

    private void loadProfile() {
        businessName.setText(prefs.getString("businessName", ""));
        businessAbn.setText(prefs.getString("businessAbn", ""));
        businessAddress.setText(prefs.getString("businessAddress", ""));
        businessContact.setText(prefs.getString("businessContact", ""));
        paymentDetails.setText(prefs.getString("paymentDetails", ""));
        gstRegistered.setChecked(prefs.getBoolean("gstRegistered", false));
        pricesIncludeGst.setChecked(prefs.getBoolean("pricesIncludeGst", true));
        pricesIncludeGst.setEnabled(gstRegistered.isChecked());
        String u = prefs.getString("logoUri", "");
        if (!u.isEmpty()) { try { logoUri = Uri.parse(u); displayLogo(); } catch (Exception ignored) {} }
        invoiceNumber.setText(nextInvoiceNumber());
        issueDate.setText(formatDate(new Date()));
        Calendar due = Calendar.getInstance(); due.add(Calendar.DAY_OF_MONTH, 14); dueDate.setText(formatDate(due.getTime()));
        updateDocumentType();
    }

    private void incrementInvoiceNumber() {
        int n = prefs.getInt("nextInvoice", 1) + 1;
        prefs.edit().putInt("nextInvoice", n).apply();
    }

    private String nextInvoiceNumber() { return String.format(Locale.US, "INV-%04d", prefs.getInt("nextInvoice", 1)); }

    private void newInvoice() {
        customerName.setText(""); customerBusiness.setText(""); customerAbn.setText(""); customerEmail.setText(""); customerAddress.setText("");
        reference.setText(""); notes.setText(""); invoiceNumber.setText(nextInvoiceNumber());
        issueDate.setText(formatDate(new Date())); Calendar due = Calendar.getInstance(); due.add(Calendar.DAY_OF_MONTH, 14); dueDate.setText(formatDate(due.getTime()));
        itemsContainer.removeAllViews(); itemRows.clear(); addItemRow("", "1", "", true); recalculate();
    }

    private void updateDocumentType() { if (documentTypeText != null) documentTypeText.setText(gstRegistered.isChecked() ? "TAX INVOICE MODE" : "INVOICE MODE"); }

    private void pickDate(EditText target) {
        Calendar c = Calendar.getInstance();
        DatePickerDialog dlg = new DatePickerDialog(this, (v, y, m, d) -> {
            Calendar selected = Calendar.getInstance(); selected.set(y, m, d); target.setText(formatDate(selected.getTime()));
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private boolean isValidAbn(String abn) {
        if (abn == null || abn.length() != 11) return false;
        int[] w = {10,1,3,5,7,9,11,13,15,17,19}; int sum = 0;
        for (int i=0;i<11;i++) { int d = abn.charAt(i)-'0'; if (d<0||d>9) return false; if (i==0) d -= 1; sum += d*w[i]; }
        return sum % 89 == 0;
    }

    private String digits(String s) { return s == null ? "" : s.replaceAll("\\D", ""); }
    private String val(EditText e) { return e.getText().toString().trim(); }
    private double number(String s) { try { return Double.parseDouble(s.trim()); } catch (Exception e) { return 0; } }
    private String trimQty(double q) { return Math.floor(q) == q ? String.valueOf((long)q) : String.valueOf(q); }
    private String cleanFileName(String s) { String x = s.replaceAll("[^a-zA-Z0-9._-]", "_"); return x.isEmpty() ? "invoice" : x; }
    private String formatDate(Date d) { return new SimpleDateFormat("dd MMM yyyy", new Locale("en", "AU")).format(d); }
    private int CYAN_DARK() { return Color.rgb(0, 130, 145); }

    private void drawRight(Canvas c, Paint p, String s, float x, float y) { c.drawText(s, x - p.measureText(s), y, p); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(12), dp(12), dp(12), dp(12)); l.setBackground(strokeBg(PANEL, Color.rgb(42,54,66), 1, 12)); return l;
    }
    private TextView section(String s) { TextView t = text(s, 12, CYAN, true); t.setPadding(dp(2), dp(22), 0, dp(8)); return t; }
    private TextView text(String s, int sp, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT_BOLD); return t; }
    private EditText field(String hint, int type) {
        EditText e = new EditText(this); e.setHint(hint); e.setHintTextColor(Color.rgb(105,120,135)); e.setTextColor(WHITE); e.setTextSize(14); e.setInputType(type); e.setPadding(dp(12), dp(12), dp(12), dp(12)); e.setBackground(strokeBg(BG, Color.rgb(49,62,75), 1, 8)); e.setSingleLine((type & InputType.TYPE_TEXT_FLAG_MULTI_LINE) == 0); e.setSelectAllOnFocus(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); p.setMargins(0, dp(5), 0, dp(5)); e.setLayoutParams(p); return e;
    }
    private CheckBox checkbox(String s, boolean checked) { CheckBox c = new CheckBox(this); c.setText(s); c.setTextColor(WHITE); c.setTextSize(13); c.setChecked(checked); c.setPadding(0, dp(5), 0, dp(5)); return c; }
    private Button button(String s, boolean filled) { Button b = new Button(this); b.setText(s); b.setTextSize(12); b.setTypeface(Typeface.DEFAULT_BOLD); b.setAllCaps(false); b.setTextColor(filled ? Color.BLACK : CYAN); b.setBackground(strokeBg(filled ? CYAN : PANEL, CYAN, 1, 9)); return b; }
    private LinearLayout.LayoutParams buttonParams() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)); p.setMargins(0, dp(8), 0, dp(2)); return p; }
    private LinearLayout.LayoutParams matchWrap() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); p.setMargins(0, 0, 0, dp(2)); return p; }
    private GradientDrawable strokeBg(int fill, int stroke, int sw, int radiusDp) { GradientDrawable g = new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radiusDp)); g.setStroke(dp(sw), stroke); return g; }
    private TextView totalLine(String label, String initial, boolean big, LinearLayout parent) {
        LinearLayout line = new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL); line.setPadding(0, dp(5), 0, dp(5));
        TextView l = text(label, big ? 14 : 12, big ? WHITE : MUTED, big); TextView v = text(initial, big ? 18 : 13, big ? CYAN : WHITE, big); v.setGravity(Gravity.END);
        line.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); line.addView(v, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); parent.addView(line); return v;
    }

    private static class ItemViews {
        final View root; final EditText desc, qty, price; final CheckBox taxable;
        ItemViews(View root, EditText desc, EditText qty, EditText price, CheckBox taxable) { this.root=root; this.desc=desc; this.qty=qty; this.price=price; this.taxable=taxable; }
    }
    private static class Totals { final double subtotal, gst, total; Totals(double s,double g,double t){subtotal=s;gst=g;total=t;} }
    private static class PdfState { final PdfDocument.Page page; final Canvas canvas; final Paint paint; PdfState(PdfDocument.Page p,Canvas c,Paint a){page=p;canvas=c;paint=a;} }
    private static class SimpleWatcher implements TextWatcher {
        final Runnable r; SimpleWatcher(Runnable r){this.r=r;} public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){r.run();} public void afterTextChanged(Editable e){}
    }
}
