# No special ProGuard rules are required for v1.
