# AU Invoice Maker v1.1.0

## Added
- Complete invoice preview before export.
- Preview renders every page of the exact PDF invoice layout.
- Save invoice as PNG.
- Multi-page invoices are exported as one tall PNG image.
- PNG files are saved to `Pictures/AU Invoice Maker`.
- Preview, PDF and PNG share the same source rendering to keep layouts consistent.

## Improved
- Export tracking now avoids advancing the invoice number twice when the same invoice is exported in more than one format during the same session.
- App subtitle and footer now show preview/PNG support.

## Existing output locations
- PDF: `Documents/AU Invoice Maker`
- PNG: `Pictures/AU Invoice Maker`
