# AU Invoice Maker

Native Android invoice app for Australian businesses.

## Features
- Australian Invoice / Tax Invoice mode
- GST registered toggle and 10% GST calculations
- GST-inclusive or GST-exclusive pricing
- ABN checksum validation
- Supplier/business profile saved locally
- Custom business logo selected from phone storage
- Customer details, ABN, email and address
- Automatic invoice numbering
- Issue date and due date pickers
- Multiple line items with quantity, unit price and taxable/non-taxable status
- Notes, purchase order/reference and payment/bank details
- ATO-oriented validation, including buyer identity details for GST invoices of $1,000+
- Full on-screen invoice preview using the exact generated PDF layout
- Professional A4 PDF generation
- Export the complete invoice as a PNG image (multi-page invoices become one tall PNG)
- Save PDF to Documents/AU Invoice Maker
- Share PDF through Android share sheet
- Preview, PDF and PNG use the same invoice rendering so the output matches
- Fully offline; no account or server required

## Build
Open this folder in Android Studio and select **Build > Build APK(s)**.

Or, if Gradle 8.9+ and Android SDK 35 are installed:

```bash
gradle :app:assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Notes
The app is designed for Android 10 (API 29) and newer. It does not transmit invoice data anywhere.
